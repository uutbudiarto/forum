<?php if ($header) { echo $header; } ?>
<?php if ($navbar) { echo $navbar; } ?>
<div id="content"><?php if ($page) { echo $page; } ?></div>
<?php if ($footer) { echo $footer; } ?>